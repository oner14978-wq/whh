# Alterações — Tela principal (reprodução da imagem de referência)

## Arquivos alterados (copie por cima do projeto, mantendo os caminhos)
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/home/HomeDashboard.kt` (reescrito)
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/LauncherScreen.kt` (nova ação `onWorlds`)
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/main/MainScreen.kt` (barra superior antiga oculta na Home)

## O que mudou
- Cenário desenhado em Canvas: céu roxo/rosa, estrelas piscando, castelo, dragão batendo asas, personagem com espada de diamante, árvore roxa e chão em blocos.
- Logo grande à esquerda (coroa + "If Cauê / Launcher"), "Minecraft Java Edition" abaixo. O texto fica nas constantes `LOGO_LINE_1` e `LOGO_LINE_2`.
- Botão "Jogar" roxo com pulso/brilho: inicia o Minecraft com a instância selecionada; sem instância, abre Instâncias.
- Barra inferior FIXA, colada na borda de baixo, com 7 itens:
  Início · Personagem (contas/personalizar personagem) · Mods · Texturas (resource packs) · Átomos (shaders) · Mundos (saves) · Configurações.
- Canto superior direito: pesquisa (baixar/buscar), notificações (painel de tarefas), coroa (Instâncias).
- A barra superior antiga só aparece nas outras telas (com o botão voltar), não mais na Home.
- Todas as medidas escalam pela altura da tela (referência 504x233).

## NÃO TESTADO
Escrito sem Android SDK/Gradle: não foi compilado nem executado. Rode `./gradlew :ZalithLauncher:assembleDebug` e me envie qualquer erro.

## Renomeação de pastas (Zalith → Cat Launcher)
- Pasta raiz `Zalith` → `Cat_Launcher`; módulo `ZalithLauncher` → `CatLauncher`.
- Atualizados: `settings.gradle.kts` (rootProject e include), `LWJGL/*/build.gradle.kts`, `.github/workflows/*.yml`.
- NÃO renomeadas: as pastas de pacote `com/movtery/zalithlauncher` (têm de coincidir com `package ...` do código e com os nomes JNI das bibliotecas nativas .so; renomear quebraria o app), `launcher_name`, `AppTheme.ZalithLauncher` e a URL do GitHub.
- Os binários omitidos (ver ARQUIVOS_OMITIDOS.txt) agora vão dentro de `CatLauncher/`, não mais `ZalithLauncher/`.

# Alterações — Conta Offline (item 7)
- NOVO `CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/elements/LocalLoginDialogNeon.kt`: nova tela "Conta Offline" (mesma assinatura `LocalLoginDialog`, então `AccountManageScreen.kt` não mudou).
- ALTERADO `AccountElements.kt`: o diálogo antigo foi só renomeado para `LegacyLocalLoginDialog` (sem uso, mantido no código).
- Visual: cartão escuro com brilho roxo/azul, ícone de usuário + título, quadro grande com o rosto e ombros do Steve (pixel art nítida), campo "Nome do Jogador:", botão roxo "Criar Conta" com ícone de confirmação e pulso luminoso.
- Funções (as mesmas do sistema de contas existente): digitar/alterar o nome (vem "SteveMinecraft" selecionado, digitar substitui), validação com mensagens (vazio, curto, longo, caracteres ilegais), nome inválido passa pelo aviso "Usar mesmo assim" já existente, UUID avançado e link de compra mantidos, conta salva no banco e selecionada ao criar (permanece após reiniciar), trocar/criar outra conta continua na tela de contas.
- Observação: o rosto exibido é o skin padrão do Steve (contas novas ainda não têm skin); depois de criada, a conta mostra o skin/personagem normalmente na lista e no perfil.
- NÃO TESTADO (sem Android SDK/Gradle).

# Alterações — Hub de conteúdo: Mods, Texturas, Addons, Mundos, Shaders
Reformulação visual das páginas de download, SOBRE o sistema real do launcher (busca Modrinth/CurseForge,
download com progresso/velocidade/SHA-1, instalação na pasta da instância, dependências, favoritos). Nada foi apagado.

## Arquivos
- NOVO `ui/screens/content/download/neon/NeonContentUi.kt`: abas neon, trilho de categorias, cartão com imagem grande, botão neon, barra de instalados.
- ALTERADO `ui/screens/content/DownloadScreen.kt`: o menu lateral virou barra de abas no topo (Mods · Texturas · Addons · Mundos · Shaders; "Jogo", "Por ID" e "Favoritos" continuam como atalhos menores) + barra inferior "Mods instalados: N / Gerenciar instalados".
- ALTERADO `.../addon/elements/_Search.Result.kt`: lista vira grade de cartões (imagem própria de cada projeto, nome, descrição, downloads, etiquetas, botão Baixar). `ResultProjectLayout` foi mantido (usado em Favoritos/Por ID).
- ALTERADO `.../addon/search/SearchAddonScreen.kt`: trilho de categorias à esquerda (como na referência). O painel de filtros à direita (busca, versão do MC, ordenação, loader, plataforma) continua.
- ALTERADO `.../addon/elements/DownloadAddonElements.kt`: cada arquivo na página do projeto mostra tamanho e versões do Minecraft compatíveis.

## Mapeamento das abas
- Mods → mods · Texturas → pacotes de recursos (pasta resourcepacks) · Addons → pacotes de mods (modpacks, instalados como instância nova)
- Mundos → saves (pasta saves; só CurseForge, o Modrinth não tem mundos) · Shaders → shaderpacks
- Imagens: vêm do próprio projeto na plataforma (logo/ícone), uma por conteúdo, com fallback de ícone se a plataforma não tiver.

## Categorias
- Cada chip aplica UMA categoria real da plataforma (as plataformas combinam várias com "E", o que zeraria a busca). Chips sem equivalente na plataforma atual ficam ocultos.
- Mods: Todos, Utilitários, Gameplay, Gráficos (= otimização/desempenho), Construção, Diversos. Cada outra aba tem seus próprios chips (ver `quickCategoriesFor`).

## Baixar / instalar / remover / atualizar
- "Baixar" abre a página do projeto: lá se escolhe o arquivo (tamanho, versão do MC, loader), e o download real roda como tarefa com progresso e velocidade (painel de tarefas/notificações), mensagem de erro em caso de falha, instalação na pasta certa e dependências.
- Remover, ativar/desativar, atualizar e importar arquivo local: telas de gerenciamento já existentes, abertas pelo botão "Gerenciar instalados".

## NÃO TESTADO
Escrito sem Android SDK/Gradle e sem rede: não foi compilado nem executado. Rode `./gradlew :CatLauncher:assembleDebug` e me envie qualquer erro.
