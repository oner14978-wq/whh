# Alterações — Remover animações/atrasos de entrada do CAT Launcher

## Arquivos (copie por cima do projeto, mantendo os caminhos)
NOVOS
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/startup/StartupAnimationGate.kt`
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/startup/ActivityTransitions.kt`

ALTERADOS
- `.../utils/animation/SwapTimeline.kt` (`isSwapClosed()` também fecha durante a abertura)
- `.../ui/base/BaseScreen.kt` (nasce visível e não espera o relógio de transição)
- `.../startup/StartupCoordinator.kt` (reabre as animações internas após o primeiro quadro)
- `.../ui/activities/SplashActivity.kt` e `MainActivity.kt`
- `CatLauncher/src/main/res/values/themes.xml` e `values-night/themes.xml`
- `CatLauncher/src/test/.../startup/StartupSystemsTest.kt` (+ `StartupAnimationGateTest`)

## O que causava o atraso
1. `BaseScreen` começava invisível e fazia `delay()` até `SwapClock.enterAtMillis` (janela de saída + GAP) antes de mostrar a tela.
2. Todo conteúdo passava por `animated(...)`: deslocamento de 350 ms + fade de 200 ms, com escalonamento por item (até 250 ms).
3. Splash do sistema com animação de saída; animação de janela Splash -> Main.

## O que foi feito
- **Porta de animações (`StartupAnimationGate`)**: fechada em toda abertura (fria e quente). Fechada = o sistema de animação de páginas se comporta como "animações desligadas": sem deslocamento, sem fade, sem escalonamento, sem espera. Nenhum temporizador de relógio: reabre contando 3 quadros desenhados após o primeiro quadro da Main (`onFirstFrame`; abertura quente: `onNewIntent`).
- **Animações internas preservadas**: depois disso, trocar de tela/aba, diálogos e a opção "animação de troca de página" do usuário funcionam como antes.
- **Splash**: `setOnExitAnimationListener { remove() }` (some no primeiro quadro), `windowSplashScreenAnimationDuration = 0`.
- **Splash -> Main**: sem animação de janela (`disableWindowTransition()` em Splash e Main; tema pós-splash próprio `AppTheme.ZalithLauncher.Splash`; só essas duas activities, as demais mantêm as transições).
- **Primeira execução**: telas Welcome/Unpacking mantêm suas animações (são interativas, não seguram a abertura); a porta fecha de novo antes de ir para a Main.
- **Imagens decorativas**: já eram assíncronas (`AsyncImage`, `crossfade(false)`, decodificação em IO); nada bloqueia a interface.
- **Sem tela preta/branca**: mantido o splash do sistema com o fundo do tema até o primeiro quadro.
- **Quatro carregadores**: intactos (Fast Async Startup Loader, Parallel Loading, Smart Cache, Lazy Loading). `onFirstFrame` continua liberando o Lazy Loading e o flush do cache.

## Pontos de atenção (não alterados de propósito)
- `MainActivity.onNewIntent` (abertura quente) chama `Renderers.init(true)` e `PluginLoader.loadAllPlugins(this, true)` na thread principal: varre todos os apps instalados. É o maior custo restante da abertura QUENTE. Não movi para segundo plano porque `Renderers` usa lista sem sincronização (risco de corrida). Dá para otimizar depois (ex.: recarregar só se a lista de pacotes mudou).
- A tarefa `preload:renderers+plugins` é ESSENCIAL na Splash (roda em paralelo com as verificações). Mantida: a Main precisa disso de qualquer forma.
- A barra de progresso ondulada da tela Loading é indicador de carregamento (não animação de entrada) e foi mantida.

## Como testar (no aparelho)
```
adb shell am force-stop <applicationId>
adb shell am start -W -S -n <applicationId>/com.movtery.zalithlauncher.ui.activities.SplashActivity   # FRIA (TotalTime)
adb shell input keyevent KEYCODE_HOME; adb shell am start -W -n <applicationId>/com.movtery.zalithlauncher.ui.activities.SplashActivity  # QUENTE
adb logcat -s Startup:I   # "Launcher ready in N ms (target ...)" + relatório por etapa
```
Conferir visualmente: sem slide/fade ao entrar, sem fade do ícone do splash, sem transição Splash -> Main; depois, trocar de aba e abrir um diálogo (devem animar normalmente).

## NÃO TESTADO
Escrito sem Android SDK/Gradle/aparelho: não compilado nem executado. Rode `./gradlew :CatLauncher:assembleDebug` e `:CatLauncher:testDebugUnitTest` e me envie qualquer erro.
