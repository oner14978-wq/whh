/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.account.wardrobe

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import androidx.annotation.StringRes
import com.movtery.zalithlauncher.R
import com.movtery.zalithlauncher.path.PathManager
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/** Categorias de itens da tela Personalizar Personagem */
enum class CosmeticCategory { HAT, CLOTHES, CAPE, ACCESSORY }

/** Um item que pode ser vestido pelo personagem */
data class CosmeticItem(
    val id: String,
    val category: CosmeticCategory,
    @StringRes val nameRes: Int
)

/**
 * Itens escolhidos pelo jogador. `null` significa "nenhum item" na categoria.
 * [cape] guarda o id de uma capa local (usada em contas offline).
 */
data class CosmeticSelection(
    val hat: String? = null,
    val clothes: String? = null,
    val accessory: String? = null,
    val cape: String? = null
) {
    fun get(category: CosmeticCategory): String? = when (category) {
        CosmeticCategory.HAT -> hat
        CosmeticCategory.CLOTHES -> clothes
        CosmeticCategory.ACCESSORY -> accessory
        CosmeticCategory.CAPE -> cape
    }

    fun with(category: CosmeticCategory, id: String?): CosmeticSelection = when (category) {
        CosmeticCategory.HAT -> copy(hat = id)
        CosmeticCategory.CLOTHES -> copy(clothes = id)
        CosmeticCategory.ACCESSORY -> copy(accessory = id)
        CosmeticCategory.CAPE -> copy(cape = id)
    }

    /** Apenas os itens que alteram a textura da skin (sem capa) */
    fun skinPart(): CosmeticSelection = copy(cape = null)

    val hasSkinItems: Boolean get() = hat != null || clothes != null || accessory != null
    val isEmpty: Boolean get() = !hasSkinItems && cape == null
}

/**
 * Persistência dos itens escolhidos e da skin original (sem itens) de cada conta.
 * A skin original é necessária para que os itens possam ser removidos depois.
 */
object CosmeticStore {
    private fun dir(): File = PathManager.DIR_ACCOUNT_SKIN

    fun baseFile(uuid: String) = File(dir(), "$uuid.base.png")
    private fun selectionFile(uuid: String) = File(dir(), "$uuid.cosmetics.json")

    fun load(uuid: String): CosmeticSelection {
        val file = selectionFile(uuid)
        if (!file.exists()) return CosmeticSelection()
        return runCatching {
            val json = JSONObject(file.readText())
            CosmeticSelection(
                hat = json.optString("hat").ifEmpty { null },
                clothes = json.optString("clothes").ifEmpty { null },
                accessory = json.optString("accessory").ifEmpty { null },
                cape = json.optString("cape").ifEmpty { null }
            )
        }.getOrDefault(CosmeticSelection())
    }

    fun save(uuid: String, selection: CosmeticSelection) {
        runCatching {
            val json = JSONObject().apply {
                put("hat", selection.hat ?: "")
                put("clothes", selection.clothes ?: "")
                put("accessory", selection.accessory ?: "")
                put("cape", selection.cape ?: "")
            }
            dir().mkdirs()
            selectionFile(uuid).writeText(json.toString())
        }
    }

    fun saveBase(uuid: String, bytes: ByteArray) {
        runCatching {
            dir().mkdirs()
            baseFile(uuid).writeBytes(bytes)
        }
    }

    fun clear(uuid: String) {
        runCatching { selectionFile(uuid).delete() }
        runCatching { baseFile(uuid).delete() }
    }
}

/**
 * Catálogo e "pintor" dos itens. Cada item é desenhado pixel a pixel nas camadas
 * externas da skin (64x64) ou, no caso das capas, em uma textura 64x32.
 */
object CosmeticCatalog {
    val hats: List<CosmeticItem> = listOf(
        CosmeticItem("hat_cat_ears", CosmeticCategory.HAT, R.string.cosmetic_hat_cat_ears),
        CosmeticItem("hat_crown", CosmeticCategory.HAT, R.string.cosmetic_hat_crown),
        CosmeticItem("hat_crown_gems", CosmeticCategory.HAT, R.string.cosmetic_hat_crown_gems),
        CosmeticItem("hat_santa", CosmeticCategory.HAT, R.string.cosmetic_hat_santa),
        CosmeticItem("hat_headphones", CosmeticCategory.HAT, R.string.cosmetic_hat_headphones),
        CosmeticItem("hat_top_hat", CosmeticCategory.HAT, R.string.cosmetic_hat_top_hat),
        CosmeticItem("hat_neon_beanie", CosmeticCategory.HAT, R.string.cosmetic_hat_neon_beanie)
    )

    val clothes: List<CosmeticItem> = listOf(
        CosmeticItem("clothes_hoodie", CosmeticCategory.CLOTHES, R.string.cosmetic_clothes_hoodie),
        CosmeticItem("clothes_neon_jacket", CosmeticCategory.CLOTHES, R.string.cosmetic_clothes_neon_jacket),
        CosmeticItem("clothes_tuxedo", CosmeticCategory.CLOTHES, R.string.cosmetic_clothes_tuxedo),
        CosmeticItem("clothes_jersey", CosmeticCategory.CLOTHES, R.string.cosmetic_clothes_jersey),
        CosmeticItem("clothes_gold_armor", CosmeticCategory.CLOTHES, R.string.cosmetic_clothes_gold_armor)
    )

    val accessories: List<CosmeticItem> = listOf(
        CosmeticItem("acc_sunglasses", CosmeticCategory.ACCESSORY, R.string.cosmetic_acc_sunglasses),
        CosmeticItem("acc_neon_glasses", CosmeticCategory.ACCESSORY, R.string.cosmetic_acc_neon_glasses),
        CosmeticItem("acc_mask", CosmeticCategory.ACCESSORY, R.string.cosmetic_acc_mask),
        CosmeticItem("acc_scarf", CosmeticCategory.ACCESSORY, R.string.cosmetic_acc_scarf),
        CosmeticItem("acc_eyepatch", CosmeticCategory.ACCESSORY, R.string.cosmetic_acc_eyepatch)
    )

    val capes: List<CosmeticItem> = listOf(
        CosmeticItem("cape_creeper", CosmeticCategory.CAPE, R.string.cosmetic_cape_creeper),
        CosmeticItem("cape_redstone", CosmeticCategory.CAPE, R.string.cosmetic_cape_redstone),
        CosmeticItem("cape_ghost", CosmeticCategory.CAPE, R.string.cosmetic_cape_ghost),
        CosmeticItem("cape_ice", CosmeticCategory.CAPE, R.string.cosmetic_cape_ice),
        CosmeticItem("cape_neon", CosmeticCategory.CAPE, R.string.cosmetic_cape_neon)
    )

    fun items(category: CosmeticCategory): List<CosmeticItem> = when (category) {
        CosmeticCategory.HAT -> hats
        CosmeticCategory.CLOTHES -> clothes
        CosmeticCategory.ACCESSORY -> accessories
        CosmeticCategory.CAPE -> capes
    }

    // ---------------------------------------------------------------- cores

    private fun c(hex: Long): Int = hex.toInt()

    private val GOLD = c(0xFFFFC928)
    private val GOLD_DARK = c(0xFFC98F0A)
    private val GOLD_LIGHT = c(0xFFFFE680)
    private val BLACK = c(0xFF0D0B14)
    private val GRAY_DARK = c(0xFF26222F)
    private val WHITE = c(0xFFF4F1FF)
    private val RED = c(0xFFD32F2F)
    private val RED_DARK = c(0xFF8E1B1B)
    private val PINK = c(0xFFFF8FD0)
    private val PINK_DARK = c(0xFFD84FA0)
    private val PURPLE = c(0xFF7B2FFF)
    private val PURPLE_DARK = c(0xFF4A1BA8)
    private val NEON = c(0xFFB57BFF)
    private val MAGENTA = c(0xFFE879F9)
    private val TRANSPARENT = 0

    // ------------------------------------------------------- utilitários

    private class Pix(val bmp: Bitmap) {
        fun px(x: Int, y: Int, color: Int) {
            if (x in 0 until bmp.width && y in 0 until bmp.height) bmp.setPixel(x, y, color)
        }

        fun rect(x: Int, y: Int, w: Int, h: Int, color: Int) {
            for (yy in y until y + h) for (xx in x until x + w) px(xx, yy, color)
        }
    }

    /** Converte skins antigas (64x32) para o formato 64x64 com camadas extras */
    private fun toModern(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint().apply { isFilterBitmap = false }
        val srcCrop = if (src.width == 64 && src.height >= 32) src else Bitmap.createScaledBitmap(src, 64, 32, false)
        canvas.drawBitmap(srcCrop, Rect(0, 0, 64, minOf(srcCrop.height, 64)), Rect(0, 0, 64, minOf(srcCrop.height, 64)), paint)
        if (srcCrop.height == 32) {
            fun mirror(sx: Int, sy: Int, dx: Int, dy: Int) {
                val part = Bitmap.createBitmap(srcCrop, sx, sy, 16, 16)
                val m = Matrix().apply { preScale(-1f, 1f) }
                val flipped = Bitmap.createBitmap(part, 0, 0, 16, 16, m, false)
                canvas.drawBitmap(flipped, dx.toFloat(), dy.toFloat(), paint)
            }
            mirror(0, 16, 16, 48)   // perna esquerda
            mirror(40, 16, 32, 48)  // braço esquerdo
        }
        return out
    }

    private fun shade(color: Int, factor: Float): Int {
        val a = (color ushr 24) and 0xFF
        val r = (((color shr 16) and 0xFF) * factor).toInt().coerceIn(0, 255)
        val g = (((color shr 8) and 0xFF) * factor).toInt().coerceIn(0, 255)
        val b = ((color and 0xFF) * factor).toInt().coerceIn(0, 255)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }

    // ----------------------------------------------------------- chapéus

    private fun paintHat(p: Pix, id: String) {
        when (id) {
            "hat_cat_ears" -> {
                p.rect(41, 1, 2, 2, PINK)
                p.rect(45, 1, 2, 2, PINK)
                p.px(41, 1, PINK_DARK); p.px(46, 1, PINK_DARK)
                p.px(41, 8, PINK); p.px(46, 8, PINK)
                p.rect(43, 0, 2, 1, PINK_DARK) // laço no topo
            }
            "hat_crown", "hat_crown_gems" -> {
                // aro dourado em volta da cabeça
                p.rect(32, 8, 32, 2, GOLD)
                p.rect(32, 9, 32, 1, GOLD_DARK)
                // pontas da coroa: linha superior alternada
                for (x in 32..63) if (x % 2 == 1) p.px(x, 8, TRANSPARENT)
                for (x in 32..63) if (x % 4 == 0) p.px(x, 8, GOLD_LIGHT)
                // topo: borda dourada com centro aberto
                p.rect(40, 0, 8, 8, GOLD)
                p.rect(41, 1, 6, 6, TRANSPARENT)
                if (id == "hat_crown_gems") {
                    p.px(41, 9, PURPLE); p.px(44, 9, MAGENTA); p.px(46, 9, PURPLE)
                    p.px(43, 8, GOLD_LIGHT)
                }
            }
            "hat_santa" -> {
                p.rect(40, 0, 8, 8, RED)
                p.rect(32, 8, 32, 1, RED)
                p.rect(32, 9, 32, 1, WHITE)
                p.rect(32, 10, 8, 1, RED_DARK) // fundo do gorro atrás
                p.rect(56, 10, 8, 1, RED_DARK)
                p.rect(43, 5, 2, 2, WHITE) // pompom
                p.rect(44, 4, 1, 1, WHITE)
            }
            "hat_headphones" -> {
                p.rect(43, 0, 2, 8, GRAY_DARK)           // arco sobre a cabeça
                p.rect(35, 8, 2, 2, GRAY_DARK)
                p.rect(51, 8, 2, 2, GRAY_DARK)
                p.rect(34, 10, 4, 4, BLACK)              // conchas
                p.rect(50, 10, 4, 4, BLACK)
                p.rect(35, 11, 2, 2, PURPLE)             // brilho neon
                p.rect(51, 11, 2, 2, PURPLE)
                p.px(36, 11, NEON); p.px(51, 11, NEON)
            }
            "hat_top_hat" -> {
                p.rect(40, 0, 8, 8, BLACK)
                p.rect(32, 8, 32, 1, BLACK)
                p.rect(32, 9, 32, 1, PURPLE)
            }
            "hat_neon_beanie" -> {
                p.rect(40, 0, 8, 8, PURPLE_DARK)
                p.rect(32, 8, 32, 2, PURPLE)
                p.rect(32, 9, 32, 1, NEON)
                for (x in 32..63) if (x % 3 == 0) p.px(x, 8, PURPLE_DARK)
                p.rect(43, 3, 2, 2, MAGENTA) // pompom neon
            }
        }
    }

    // ------------------------------------------------------------ roupas

    private fun torsoAndArms(p: Pix, color: Int) {
        // tronco (anel externo + topo/base)
        p.rect(16, 36, 24, 12, color)
        p.rect(20, 32, 16, 4, color)
        // braço direito
        p.rect(40, 36, 16, 12, color)
        p.rect(44, 32, 8, 4, color)
        // braço esquerdo
        p.rect(48, 52, 16, 12, color)
        p.rect(52, 48, 8, 4, color)
    }

    private fun legs(p: Pix, color: Int) {
        p.rect(0, 36, 16, 12, color)
        p.rect(4, 32, 8, 4, color)
        p.rect(0, 52, 16, 12, color)
        p.rect(4, 48, 8, 4, color)
    }

    private fun paintClothes(p: Pix, id: String) {
        when (id) {
            "clothes_hoodie" -> {
                torsoAndArms(p, PURPLE)
                p.rect(16, 36, 24, 2, NEON)           // gola/capuz
                p.rect(22, 44, 4, 2, PURPLE_DARK)     // bolso
                p.px(23, 38, WHITE); p.px(24, 38, WHITE)
                p.px(23, 39, WHITE); p.px(24, 39, WHITE)
                p.rect(40, 46, 16, 2, PURPLE_DARK)    // punhos
                p.rect(48, 62, 16, 2, PURPLE_DARK)
                legs(p, PURPLE_DARK)
            }
            "clothes_neon_jacket" -> {
                torsoAndArms(p, BLACK)
                for (y in 36..47) { p.px(21, y, NEON); p.px(26, y, NEON) }
                p.rect(16, 36, 24, 1, PURPLE)
                p.rect(40, 40, 16, 1, NEON)
                p.rect(48, 56, 16, 1, NEON)
                legs(p, GRAY_DARK)
                p.rect(0, 36, 16, 1, PURPLE)
                p.rect(0, 52, 16, 1, PURPLE)
            }
            "clothes_tuxedo" -> {
                torsoAndArms(p, BLACK)
                for (y in 37..43) { p.px(23, y, WHITE); p.px(24, y, WHITE) }
                p.px(22, 36, WHITE); p.px(25, 36, WHITE)
                p.rect(23, 36, 2, 1, RED)             // gravata borboleta
                p.px(22, 36, RED); p.px(25, 36, RED)
                legs(p, BLACK)
            }
            "clothes_jersey" -> {
                torsoAndArms(p, RED)
                p.rect(16, 40, 24, 2, WHITE)
                p.rect(40, 40, 16, 1, WHITE)
                p.rect(48, 56, 16, 1, WHITE)
                legs(p, WHITE)
                p.rect(0, 36, 16, 1, RED)
                p.rect(0, 52, 16, 1, RED)
            }
            "clothes_gold_armor" -> {
                torsoAndArms(p, GOLD)
                p.rect(16, 36, 24, 1, GOLD_LIGHT)
                p.rect(16, 47, 24, 1, GOLD_DARK)
                p.rect(21, 38, 6, 1, GOLD_DARK); p.rect(21, 41, 6, 1, GOLD_DARK)
                p.rect(40, 36, 16, 2, GOLD_LIGHT)     // ombreiras
                p.rect(48, 52, 16, 2, GOLD_LIGHT)
                legs(p, GOLD_DARK)
                p.rect(0, 46, 16, 2, GOLD)
                p.rect(0, 62, 16, 2, GOLD)
            }
        }
    }

    // -------------------------------------------------------- acessórios

    private fun paintAccessory(p: Pix, id: String) {
        when (id) {
            "acc_sunglasses" -> {
                p.rect(41, 10, 3, 2, BLACK)
                p.rect(45, 10, 3, 2, BLACK)
                p.px(44, 10, BLACK)
                p.rect(35, 10, 5, 1, BLACK)   // hastes
                p.rect(48, 10, 5, 1, BLACK)
            }
            "acc_neon_glasses" -> {
                for (x in 41..43) p.px(x, 10, NEON)
                for (x in 45..47) p.px(x, 10, NEON)
                p.px(41, 11, NEON); p.px(43, 11, NEON); p.px(45, 11, NEON); p.px(47, 11, NEON)
                p.px(42, 11, PURPLE_DARK); p.px(46, 11, PURPLE_DARK)
                p.px(44, 10, NEON)
                p.rect(35, 10, 5, 1, NEON)
                p.rect(48, 10, 5, 1, NEON)
            }
            "acc_mask" -> {
                p.rect(40, 13, 8, 3, c(0xFFDCEBFF))
                p.rect(40, 14, 8, 1, c(0xFFB8D4F5))
                p.rect(37, 13, 3, 1, WHITE)   // elásticos
                p.rect(48, 13, 3, 1, WHITE)
            }
            "acc_scarf" -> {
                p.rect(16, 36, 24, 3, RED)
                p.rect(16, 38, 24, 1, RED_DARK)
                p.rect(20, 32, 8, 4, RED)
                p.rect(24, 39, 3, 6, RED)
                p.rect(24, 44, 3, 1, RED_DARK)
            }
            "acc_eyepatch" -> {
                p.rect(32, 9, 32, 1, BLACK)   // tira em volta da cabeça
                p.rect(41, 10, 3, 3, BLACK)
            }
        }
    }

    // ------------------------------------------------------- composição

    /**
     * Aplica os itens sobre a skin base e devolve uma nova skin 64x64.
     * A skin base nunca é modificada.
     */
    fun composeSkin(base: Bitmap, selection: CosmeticSelection): Bitmap {
        val out = toModern(base).let { if (it.isMutable) it else it.copy(Bitmap.Config.ARGB_8888, true) }
        val p = Pix(out)
        selection.clothes?.let { paintClothes(p, it) }
        selection.accessory?.let { paintAccessory(p, it) }
        selection.hat?.let { paintHat(p, it) }
        return out
    }

    /** Miniatura 8x12 (topo + rosto) de chapéu ou acessório sobre a skin do jogador */
    fun headThumbnail(base: Bitmap, item: CosmeticItem): Bitmap {
        val sel = CosmeticSelection().with(item.category, item.id)
        val skin = composeSkin(base, sel)
        val out = Bitmap.createBitmap(8, 12, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint().apply { isFilterBitmap = false }
        // topo (metade mais próxima do rosto) base + camada externa
        canvas.drawBitmap(skin, Rect(8, 4, 16, 8), Rect(0, 0, 8, 4), paint)
        canvas.drawBitmap(skin, Rect(40, 4, 48, 8), Rect(0, 0, 8, 4), paint)
        // rosto base + camada externa
        canvas.drawBitmap(skin, Rect(8, 8, 16, 16), Rect(0, 4, 8, 12), paint)
        canvas.drawBitmap(skin, Rect(40, 8, 48, 16), Rect(0, 4, 8, 12), paint)
        return out
    }

    /** Miniatura 16x12 (braços + tronco) de roupa sobre a skin do jogador */
    fun clothesThumbnail(base: Bitmap, item: CosmeticItem): Bitmap {
        val sel = CosmeticSelection().with(item.category, item.id)
        val skin = composeSkin(base, sel)
        val out = Bitmap.createBitmap(16, 12, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint().apply { isFilterBitmap = false }
        canvas.drawBitmap(skin, Rect(44, 20, 48, 32), Rect(0, 0, 4, 12), paint)
        canvas.drawBitmap(skin, Rect(44, 36, 48, 48), Rect(0, 0, 4, 12), paint)
        canvas.drawBitmap(skin, Rect(20, 20, 28, 32), Rect(4, 0, 12, 12), paint)
        canvas.drawBitmap(skin, Rect(20, 36, 28, 48), Rect(4, 0, 12, 12), paint)
        canvas.drawBitmap(skin, Rect(36, 52, 40, 64), Rect(12, 0, 16, 12), paint)
        canvas.drawBitmap(skin, Rect(52, 52, 56, 64), Rect(12, 0, 16, 12), paint)
        return out
    }

    // ------------------------------------------------------------- capas

    /** Gera a textura 64x32 da capa local. Retorna null para id desconhecido. */
    fun capeBitmap(id: String): Bitmap? {
        if (capes.none { it.id == id }) return null
        val bmp = Bitmap.createBitmap(64, 32, Bitmap.Config.ARGB_8888)
        val p = Pix(bmp)

        // pinta a "frente" (1,1) e as "costas" (12,1) com o mesmo desenho
        fun panel(ox: Int, body: (lx: Int, ly: Int) -> Int) {
            for (ly in 0 until 16) for (lx in 0 until 10) p.px(ox + lx, 1 + ly, body(lx, ly))
        }

        fun design(x: Int, y: Int): Int = when (id) {
            "cape_creeper" -> {
                val g = c(0xFF4CAF50)
                var col = if ((x * 7 + y * 13) % 5 == 0) shade(g, 0.82f) else g
                val eye = (x in 2..3 || x in 6..7) && y in 3..5
                val mouth = (x in 4..5 && y in 6..9) || (x in 3..6 && y in 8..11 && !(x in 4..5 && y in 10..11))
                if (eye || mouth) col = BLACK
                col
            }
            "cape_redstone" -> {
                var col = if ((x + y) % 4 == 0) shade(RED, 0.8f) else RED
                if (x == 0 || x == 9 || y == 0 || y == 15) col = RED_DARK
                if (kotlin.math.abs(x - 4) + kotlin.math.abs(y - 7) <= 3) col = WHITE
                if (kotlin.math.abs(x - 4) + kotlin.math.abs(y - 7) <= 1) col = BLACK
                col
            }
            "cape_ghost" -> {
                var col = if (y % 5 == 4) c(0xFFD9D6E6) else c(0xFFF2F0FA)
                if ((x in 2..3 || x in 6..7) && y in 4..6) col = BLACK
                if (x in 4..5 && y in 8..10) col = c(0xFF2A2538)
                if (y >= 14 && x % 2 == 0) col = TRANSPARENT
                col
            }
            "cape_ice" -> {
                var col = c(0xFF29B6F6)
                if ((x + y) % 6 == 0) col = c(0xFFB3E5FC)
                if (x == 0 || x == 9 || y == 0 || y == 15) col = c(0xFF0277BD)
                if ((x - y).let { kotlin.math.abs(it) } % 6 == 0 && y in 3..12) col = c(0xFFE1F5FE)
                col
            }
            else -> { // cape_neon
                var col = c(0xFF14091F)
                if ((x + y) % 5 == 0) col = c(0xFF1E0F33)
                if (x == 0 || x == 9 || y == 0 || y == 15) col = NEON
                if (x == 1 || x == 8 || y == 1 || y == 14) col = PURPLE_DARK
                if (kotlin.math.abs(x - 4) + kotlin.math.abs(y - 7) <= 3 ||
                    kotlin.math.abs(x - 5) + kotlin.math.abs(y - 7) <= 3) col = MAGENTA
                if (kotlin.math.abs(x - 4) + kotlin.math.abs(y - 7) <= 1) col = WHITE
                col
            }
        }

        // laterais, topo e base com a cor predominante do desenho
        val edge = design(0, 8).let { if (it == TRANSPARENT) design(1, 8) else it }
        p.rect(1, 0, 10, 1, edge)
        p.rect(11, 0, 10, 1, edge)
        p.rect(0, 1, 1, 16, edge)
        p.rect(11, 1, 1, 16, edge)
        p.rect(21, 1, 1, 16, edge)
        panel(1, ::design)
        panel(12, ::design)
        return bmp
    }

    fun toPng(bitmap: Bitmap): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        return stream.toByteArray()
    }

    fun capePng(id: String): ByteArray? = capeBitmap(id)?.let { toPng(it) }

    /** Miniatura 10x16 da capa (parte visível, as costas) */
    fun capeThumbnail(id: String): Bitmap? {
        val cape = capeBitmap(id) ?: return null
        return Bitmap.createBitmap(cape, 12, 1, 10, 16)
    }
}
