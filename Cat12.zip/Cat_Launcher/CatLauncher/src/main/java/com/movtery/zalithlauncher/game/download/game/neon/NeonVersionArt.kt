/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.download.game.neon

import com.google.gson.JsonParser
import com.movtery.zalithlauncher.utils.logging.Logger
import com.movtery.zalithlauncher.utils.network.fetchStringFromUrls
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private const val TAG = "NeonVersionArt"

/**
 * Imagens oficiais de cada versão do Minecraft, vindas do feed de notas de atualização
 * da própria Mojang (o mesmo usado pelo launcher oficial).
 */
object NeonVersionArt {
    private const val BASE = "https://launchercontent.mojang.com"
    private const val FEED = "$BASE/v2/javaPatchNotes.json"

    private val _images = MutableStateFlow<Map<String, String>>(emptyMap())

    /** versão (ex.: "1.21.10") -> URL da imagem oficial */
    val images: StateFlow<Map<String, String>> = _images.asStateFlow()

    suspend fun load(force: Boolean = false) {
        if (!force && _images.value.isNotEmpty()) return
        runCatching {
            val root = JsonParser.parseString(fetchStringFromUrls(listOf(FEED))).asJsonObject
            val result = HashMap<String, String>()
            root.getAsJsonArray("entries")?.forEach { element ->
                val entry = element.asJsonObject
                val version = entry.get("version")?.takeIf { it.isJsonPrimitive }?.asString ?: return@forEach
                val path = entry.getAsJsonObject("image")?.get("url")?.takeIf { it.isJsonPrimitive }?.asString
                    ?: return@forEach
                result[version] = if (path.startsWith("http")) path else BASE + (if (path.startsWith("/")) path else "/$path")
            }
            _images.value = result
        }.onFailure {
            Logger.warning(TAG, "Failed to load official version art", it)
        }
    }

    /**
     * Procura a imagem oficial da versão. Se a Mojang não publicou uma imagem exata,
     * usa a da mesma linha (ex.: 1.20.4 -> 1.20) para continuar sendo uma arte original do Minecraft.
     */
    fun find(images: Map<String, String>, id: String): String? {
        images[id]?.let { return it }
        val match = Regex("^(\\d+)\\.(\\d+)(?:\\.(\\d+))?").find(id) ?: return null
        val (major, minor) = match.destructured
        images["$major.$minor"]?.let { return it }
        return images.entries
            .filter { it.key.startsWith("$major.$minor.") }
            .maxByOrNull { it.key }
            ?.value
    }
}
